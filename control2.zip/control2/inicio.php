<!DOCTYPE html>
<html>
    
<head>
    <title>Registrar usuario</title>
    <meta charset="utf-8">
    <link rel="stylesheet"  href="css/estilo.css">

</head>
<body>
    <h1>Registro</h1>
    <form method="post" onsubmit="return validateForm()">
        <h2>Crear cuenta</h2>
        <input type="text" id="name" name="name" placeholder="Nombre completo">
        <input type="password" id="password" name="password" placeholder="Contraseña">
        <input type="text" name="edad" placeholder="Edad">
        <input type="submit" name="register" value="Registrarse">
    </form>
    


    
    <h2>Iniciar sesión</h2>
    <form method="post" action="login.php">
        <input type="text" name="username" placeholder="Nombre de usuario">
        <input type="password" name="password" placeholder="Contraseña">
        <input type="submit" name="login" value="Iniciar sesión">

    </form>
    
    <?php 
        include("usuarios.php");
        ?>

</body>
</html>
