<?php
include("con_db.php");

if (isset($_POST['register'])) {
    // Verificar que se hayan proporcionado todos los campos
    if(strlen($_POST['name']) >= 1 && strlen($_POST['password']) >= 1 && strlen($_POST['edad']) >= 1) {
        $name = trim($_POST['name']);
        $password = trim($_POST['password']);
        $edad = intval($_POST['edad']); // Convertir la edad a un entero

        // Verificar si el usuario ya existe antes de insertar
        $consulta_existencia = "SELECT * FROM usuarios WHERE nombre_usuario = '$name'";
        $resultado_existencia = mysqli_query($conex, $consulta_existencia);

        if (mysqli_num_rows($resultado_existencia) == 0) {
            // El usuario no existe, se puede insertar
            $consulta = "INSERT INTO usuarios(nombre_usuario, contraseña, edad) VALUES ('$name', '$password', $edad)";
            $resultado = mysqli_query($conex, $consulta);

            if ($resultado) {
                ?>
                <h3 class="ok">¡Te has inscripto correctamente!</h3>
                <?php
            } else {
                ?>
                <h3 class="bad">¡Ups ha ocurrido un error!</h3>
                <?php
            }
        } else {
            ?>
            <h3 class="bad">¡El usuario ya existe!</h3>
            <?php
        }
    } else {
        ?>
        <h3 class="bad">¡Por favor complete todos los campos!</h3>
        <?php
    }
}


?>
