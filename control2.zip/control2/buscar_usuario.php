<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar Tabla</title>
    <style type="text/css">
        * {
            padding: 0;
            margin: 0;
            font-family: century gothic;
            text-align: center;
        }

        .topnav {
            overflow: hidden;
            background-color: #333;
        }

        .topnav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .topnav ul li {
            float: left;
        }

        .topnav ul li a {
            display: block;
            color: #fff;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .topnav ul li a:hover {
            background-color: #555;
        }

        /* Estilos para el contenedor de la tabla */
        #tabla-container {
            width: 80%; /* Ancho de la tabla */
            margin: 50px auto 0 auto; /* Centrar horizontalmente y agregar margen superior */
            text-align: center; /* Centrar contenido de la tabla */
        }

        /* Estilos para la tabla */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        /* Estilos para el buscador */
        #searchInput {
            width: 50%;
            padding: 12px;
            margin: 10px auto; /* Centro verticalmente */
            display: block;
            box-sizing: border-box;
        }
        /* Agregamos estilos para las flechas de filtrado */
        .filter-arrow {
            cursor: pointer;
        }

        
    </style>
</head>
<body>
    <div class="topnav">
        <ul>
            <li><a href="menu.php">Inicio</a></li>
            <li><a href="#">Mostrar Tabla</a></li>
            <li><a href="MostrarMapa.php">Mapa Conceptual</a></li>
            <li><a href="inicio.php">Cerrar Sesión</a></li>
        </ul>
    
        <div class = "bubbles"> 
            <span style="--i:11"></span>
            <span style="--i:12"></span>
            <span style="--i:24"></span>
            <span style="--i:10"></span>
            <span style="--i:14"></span>
            <span style="--i:23"></span>
            <span style="--i:18"></span>
            <span style="--i:16"></span>
            <span style="--i:19"></span>
            <span style="--i:20"></span>
            <span style="--i:22"></span>
            <span style="--i:25"></span>
            <span style="--i:18"></span>
            <span style="--i:21"></span>
            <span style="--i:15"></span>
            <span style="--i:13"></span>
            <span style="--i:26"></span>
            <span style="--i:17"></span>
            <span style="--i:13"></span>
            <span style="--i:11"></span>
        </div>
        

    </div>

    
    <!-- Contenedor del buscador -->
    <input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Buscar por nombre...">
    

    <!-- Contenedor de la tabla -->
    <div id="tabla-container">

    
    <?php
    // Validamos datos del servidor
    $user = "root";
    $pass = "";
    $host = "localhost";
    $db_name = "usuarios"; // Nombre de la base de datos

    // Conectamos a la base de datos
    $connection = mysqli_connect($host, $user, $pass, $db_name);

    // Verificamos la conexión a la base de datos
    if(!$connection) {
        echo "No se ha podido conectar con el servidor" . mysqli_connect_error();
    } else {
        echo "";
    }

    // Consultar datos de la tabla
    $consulta = "SELECT * FROM usuarios"; // Nombre correcto de la tabla

    // Verificar si se ha enviado un parámetro de ordenamiento
    $order = isset($_GET['order']) ? $_GET['order'] : '';
    if ($order === 'asc') {
        $consulta .= " ORDER BY edad ASC";
    } elseif ($order === 'desc') {
        $consulta .= " ORDER BY edad DESC";
    }

    $result = mysqli_query($connection, $consulta);
    if(!$result) {
        echo "No se ha podido realizar la consulta";
    }


    
    echo "<table id='user-table'>";
    echo "<tr>";
    echo "<th><h1>ID</th></h1>"; // Corregir la etiqueta th
    echo "<th><h1>Nombre</th></h1>";
    echo "<th><h1>Edad 
        <!-- Agregamos las flechas de filtrado -->
        <span class='filter-arrow' onclick='toggleAgeFilter(\"$order\")'>⇅</span>
    </h1></th>";
    echo "</tr>";

    while ($colum = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td><h2>" . $colum['id']. "</td></h2>";
        echo "<td><h2>" . $colum['nombre_usuario']. "</td></h2>"; // Corregir el nombre de la columna
        echo "<td><h2>" . $colum['edad'] . "</td></h2>";
        echo "</tr>";
    }

    echo "</table>";

    mysqli_close($connection);
    ?>




    </div>

    <script src="js/script.js"></script>

</body>
</html>
