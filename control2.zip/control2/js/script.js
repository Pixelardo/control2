function toggleSearch() {
    var searchContainer = document.getElementById("search-container");
    var bookTable = document.getElementById("book-table");
    if (searchContainer.style.display === "none") {
        searchContainer.style.display = "block";
        bookTable.style.display = "block";
    } else {
        searchContainer.style.display = "none";
        bookTable.style.display = "none";
    }
}

function searchBooks() {
    var bookTable = document.getElementById('book-table');
    bookTable.style.display = 'block';
}


function searchTable() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("user-table");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[1]; // 1 para la columna del nombre
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}

// Función para cambiar el filtro de edad
function toggleAgeFilter(order) {
    var newOrder = (order === 'asc') ? 'desc' : 'asc';
    window.location.search = 'order=' + newOrder;
}


document.addEventListener('DOMContentLoaded', function() {
    var botonesVerMas = document.querySelectorAll('.ver-mas');
    botonesVerMas.forEach(function(boton) {
        boton.addEventListener('click', function() {
            var descripcion = this.parentNode.querySelector('.descripcion');
            if (descripcion.style.display === 'none') {
                descripcion.style.display = 'block';
            } else {
                descripcion.style.display = 'none';
            }
        });
    });
});
