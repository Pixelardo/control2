<?php
session_start();

if(isset($_POST['login'])) {
    include("con_db.php");
    
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $consulta = "SELECT * FROM usuarios WHERE nombre_usuario='$username' AND contraseña='$password'";
    $resultado = mysqli_query($conex, $consulta);

    if(mysqli_num_rows($resultado) > 0) {
        // El usuario existe, iniciar sesión
        $_SESSION['username'] = $username;
        header("Location: menu.php"); // Redireccionar al usuario a una página de bienvenida
        exit();
    } else {
        echo "Nombre de usuario o contraseña incorrectos";
    }
}
?>


